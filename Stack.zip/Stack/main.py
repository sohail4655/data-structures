class Stack:
    array=[-1]*100
    top=0
    size=0
    def __init__(self,n):
        self.size=n
    def isempty(self):
        return self.top==0
    def isfull(self):
        return self.top==self.size
    def push(self,value):
        if(self.isfull()):
            print("Stack is full")
            return
        self.array[self.top]=value
        self.top=self.top+1
    def pop(self):
        if(self.isempty()):
            print("Stack is empty , can't pop")
            return
        value=self.array[self.top-1]
        self.top = self.top - 1
        return value
    def peek(self):
        if (self.isempty()):
            print("Stack is empty , can't peek")
            return
        return self.array[self.top-1]
    def display(self):
        if (self.isempty()):
            print("Stack is empty , can't display")
            return
        print("The Stack :",end=' ')
        for i in range(self.top):
            print(self.array[i],end='  ')
        print("")
    def reverse (self):
        stack = [-1]*self.size
        i=0
        top=self.top
        print("Reversed Stack :",end=' ')
        while(not self.isempty()):
            value=self.pop()
            print(value,end=' ')
            stack[i]=value
            i=i+1
        print("")
        self.array=stack
        self.top=top


stack=Stack(4)
stack.push(5)
stack.push(4)
stack.push(7)
stack.push(9)
stack.reverse()
print(stack.peek())



