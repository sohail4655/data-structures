class Queue:
    def __init__(self,n):
        self.fpointer=0
        self.epointer = 0
        self.queue=[-1]*n
        self.size=0
    def enqueue(self,x):
        if(self.size==4):
            return 0
        self.size=self.size+1
        if(self.size<=len(self.queue)):
           self.queue[self.epointer]=x
           self.epointer=(self.epointer+1)%len(self.queue)
    def isempty(self):
        if( self.size==0 or self.epointer==self.fpointer):
            return 1
        return 0
    def dequeue(self):
        if(self.isempty()):
            print("empty")
            return -1
        else:
            self.size=self.size-1
            x=self.queue[self.fpointer]
            self.fpointer=(self.fpointer+1)%len(self.queue)
            return x
    def display(self):
        s=Queue(len(self.queue))
        while(not(self.isempty())):
            x=self.dequeue()
            s.enqueue(x)
            print(x,end='')
        while(not(s.isempty())):
            self.enqueue(s.dequeue())