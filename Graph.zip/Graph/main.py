from Heap import Heap
from Queue import Queue
def DijkstraAlgorthim(input,start,edges,vertices):
    Shortestpaths=["" for x in range(vertices)]
    visited = [-1] * vertices
    visited[0] = start
    visited_elements = 1
    graph = [([0] * vertices) for i in range(vertices)]
    for i in range(vertices):
        for j in range(vertices):
            graph[i][j]=input[i][j]
            if(i==j):
                graph[i][j]=0
    heap = Heap(vertices)
    str1=''
    for i in range(vertices):
        if start==i:
            str1=str(i)+"$"+str(0)
        else:
            str1=str(i)+"$"+str(100000)
        heap.insertheap2(str1)
    j = 0
    while(not(heap.isempty())):
        heap.heapsort2()
        print("heap is ",end='')
        heap.printheap()
        minedge = str(heap.pop2())
        print("Min edge",end='')
        print(minedge)
        arr = minedge.split('$')
        vertix=int(arr[0])
        value= int(arr[1])
        if(not(visited.__contains__(vertix))):
            visited.append(vertix)
            visited_elements=visited_elements+1
        Shortestpaths[j]="The vertix "+str(vertix)+" can be reached by "+str(value)
        j=j+1
        for i in range(vertices):
            if(graph[vertix][i] != 0):
                for k in range(heap.pointer):
                    search=str(heap.heaparray[k])
                    arr2=search.split('$')
                    if(i==int(arr2[0])):
                        index=k
                        old_value=int(arr2[1])
                        break
                if(graph[vertix][i]+value<old_value and not(visited.__contains__(i))):
                    str1 = str(i) + "$" + str(graph[vertix][i]+value)
                    heap.heaparray[index]=str1
                    print("new update is",end='')
                    print(str1)
                    print("updated heap is ", end='')
                    heap.printheap()
                    heap.heapsort2()
                    print("sorted heap is ", end='')
                    heap.printheap()
    print(j)
    for i in range(vertices):
        print(Shortestpaths[i],end='  ')
        print("-------------------------------------------------------------------------- ")


def PrimAlgorthim(input,start,edges,vertices):
    graph = [([0] * vertices) for i in range(vertices)]
    for i in range(vertices):
        for j in range(vertices):
            graph[i][j]=input[i][j]

    if(edges==(vertices-1)):
        for i in range(vertices):
            print(graph[i])
        return
    heap=Heap(edges)
    visited=[-1]*vertices
    visited[0]=start
    visited_elements=1
    sumofedges=0
    flag=0
    Mintree = [([0] * vertices) for i in range(vertices)]
    next=start
    for k in range(vertices-1):
       for i in range(vertices):
          if(graph[next][i]!=0):
             heap.insertheap(str(graph[next][i])+"$"+str(next)+"$"+str(i))


       while(1):
          heap.heapsort()
          flag=0
          minedge=str(heap.pop())
          arr=minedge.split('$')
          for j in range(visited_elements):
             if (int(arr[2])==visited[j]):
                flag=1
                break
          if(flag==0):
              visited[visited_elements]=int(arr[2])
              visited_elements=visited_elements+1
              break
       Mintree[int(arr[1])][int(arr[2])]=int(arr[0])
       Mintree[int(arr[2])][int(arr[1])] = int(arr[0])
       sumofedges=sumofedges+int(arr[0])
       graph[int(arr[1])][int(arr[2])]=0
       graph[int(arr[2])][int(arr[1])] = 0
       next=int(arr[2])
    print("Sum of edges (Minimum) = ",end='')
    print(sumofedges)
    for i in range(vertices):
        print(Mintree[i])

def isconnected(input,vertices):
    graph = [([0] * vertices) for i in range(vertices)]
    for i in range(vertices):
        for j in range(vertices):
            graph[i][j] = input[i][j]
    q=Queue(vertices)
    unvisited_nodes=vertices
    visited=1
    visited_nodes=[-1]*vertices
    visited_nodes[0]=0
    q.enqueue(0)
    while(not (q.isempty()) and visited != vertices):
            z=q.dequeue()
            for k in range(vertices):
                if(graph[z][k]!=0):
                    if(not(visited_nodes.__contains__(k))):
                        visited_nodes[visited]=k
                        visited=visited+1
                    q.enqueue(k)
                    graph[z][k]=0
                    graph[k][z] = 0
    if(visited==vertices):
        return 1
    else:
        return 0
def checkfloat(str):
    if (str.__contains__('.')):
        flag = 1
        number = float(str)
    else:
        number = int(str)
        flag = 0
    return number,flag
def loadgraph():
    loop1 = 0
    vertices = int(input("Enter number of vertices: "))
    if (vertices > 1):
        graph = [([0] * vertices) for i in range(vertices)]
    else:
        while (vertices <= 1):
            vertices = int(input("Enter number of vertices: "))
        graph = [([0] * vertices) for i in range(vertices)]
    countedges = 0
    while (not (isconnected(graph, vertices))):
        if (loop1 != 0):
            print("The graph is disconnected !!")
            graph = [([0] * vertices) for i in range(vertices)]
        print("Enter the edges and Enter End to exit: ")
        for i in range(vertices * (vertices - 1) // 2):
            edge = input("Edge: ")
            if edge == "end":
                break
            arr = edge.split(',')
            if (int(arr[0]) < vertices and int(arr[1]) < vertices and int(arr[0]) != int(arr[1])):
                check = input("it's weight: ")
                weight, flag = checkfloat(check)
                if (weight > 0 and not (flag) and graph[int(arr[0])][int(arr[1])] == 0 and graph[int(arr[1])][
                    int(arr[0])] == 0):
                    graph[int(arr[0])][int(arr[1])] = weight
                    graph[int(arr[1])][int(arr[0])] = weight
                    countedges = countedges + 1
                elif (graph[int(arr[0])][int(arr[1])] != 0 or graph[int(arr[1])][int(arr[0])] != 0):
                    print("no multiple edges , it is an undirected graph")
                else:
                    print("invalid weight")
            elif (int(arr[0]) == int(arr[1])):
                print("it can't be self loops in undirected graph")
            else:
                print("invalid edge")
        loop1 = loop1 + 1
    for i in range(vertices):
        print(graph[i])
    return vertices,countedges,graph


print("1- Prim's Algorthim")
print("2- Dijkstra's Algorthim")
choice=int(input())
if(choice==1):
    vertices,countedges,graph=loadgraph()
    first = input("Which node do you want to start with ?")
    start,flag2=checkfloat(first)
    if(not(start<vertices and start>=0) or  flag2):
        while (not(start<vertices and start>=0) or flag2):
            first=input("Invalid input , Which node do you want to start with ? ")
            start, flag2 = checkfloat(first)
            if((start<vertices and start>=0) and not (flag2)):
               PrimAlgorthim(graph,start,countedges,vertices)
               break
    else:
        PrimAlgorthim(graph, start, countedges, vertices)
elif(choice==2):
    print("1-directed")
    print("2-undirected")
    type=int(input())
    if(type==1):
        loop1 = 0
        vertices = int(input("Enter number of vertices: "))
        if (vertices > 1):
            graph = [([0] * vertices) for i in range(vertices)]
        countedges=0
        while (not (isconnected(graph, vertices))):
            if (loop1 != 0):
                print("The graph is disconnected !!")
                graph = [([0] * vertices) for i in range(vertices)]
            print("Enter the edges and Enter End to exit: ")
            for i in range(vertices * (vertices - 1)):
                edge = input("Edge: ")
                if edge == "end":
                    break
                arr = edge.split(',')
                if (int(arr[0]) < vertices and int(arr[1]) < vertices):
                    check = input("it's weight: ")
                    weight, flag = checkfloat(check)
                    if (weight > 0 and not (flag) and graph[int(arr[0])][int(arr[1])] == 0):
                        graph[int(arr[0])][int(arr[1])] = weight
                        countedges = countedges + 1
                    elif (graph[int(arr[0])][int(arr[1])] != 0):
                        print("no multiple edges ")
                    else:
                        print("invalid weight")
                else:
                    print("invalid edge")
            loop1 = loop1 + 1
        for i in range(vertices):
            print(graph[i])

        first = input("Which node do you want to start with ?")
        start, flag2 = checkfloat(first)
        if (not (start < vertices and start >= 0) or flag2):
            while (not (start < vertices and start >= 0) or flag2):
                first = input("Invalid input , Which node do you want to start with ? ")
                start, flag2 = checkfloat(first)
                if ((start < vertices and start >= 0) and not (flag2)):
                    DijkstraAlgorthim(graph, start, countedges, vertices)
                    break
        else:
           DijkstraAlgorthim(graph,start ,countedges, vertices)
    elif(type==2):
        vertices, countedges, graph = loadgraph()
        first = input("Which node do you want to start with ?")
        start, flag2 = checkfloat(first)
        if (not (start < vertices and start >= 0) or flag2):
            while (not (start < vertices and start >= 0) or flag2):
                first = input("Invalid input , Which node do you want to start with ? ")
                start, flag2 = checkfloat(first)
                if ((start < vertices and start >= 0) and not (flag2)):
                    DijkstraAlgorthim(graph, start, countedges, vertices)
                    break
        else:
            DijkstraAlgorthim(graph,start ,countedges, vertices)
    else:print("invalid input")
else:
    print("invalid input")
