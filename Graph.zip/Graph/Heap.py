class Heap:
    def __init__(self,n):
        self.heaparray=[0]*n
        self.pointer=0

    def swap(self, x1, x2):
        temp = self.heaparray[x1]
        self.heaparray[x1] = self.heaparray[x2]
        self.heaparray[x2] = temp

    def siftup(self,i):
        parent = (i - 1) // 2
        arr1=str(self.heaparray[parent]).split('$')
        arr2=str(self.heaparray[i]).split('$')
        while ((i != 0) and int(arr2[0])>int(arr1[0])):
            self.swap(i,parent)
            i = parent
            parent = (i - 1) // 2

    def buildheap(self,arr):
        for i in range(len(arr)):
            self.insertheap(arr[i])

    def insertheap(self, x):
        self.heaparray[self.pointer] = x
        self.siftup(self.pointer)
        self.pointer += 1
    def printheap(self):
        for i in range(self.pointer):
            print(self.heaparray[i])

    def pop(self):
      x = self.heaparray[0]
      self.pointer=self.pointer-1
      self.heaparray[0] = self.heaparray[self.pointer]
      self.siftdown(0)
      return x
    def siftdown(self,i):
        large = i
        l = 2 * i + 1
        r = 2 * i + 2
        if(l<self.pointer):
           arr1 = str(self.heaparray[l]).split('$')
        else:
            arr1=[0,0,0]
        arr2 = str(self.heaparray[large]).split('$')
        if (r < self.pointer):
            arr3 = str(self.heaparray[r]).split('$')
        else:
            arr3=[0,0,0]
        if (l < self.pointer and int(arr1[0]) > int(arr2[0])):
            large=l
        if (r < self.pointer and int(arr3[0]) > int(arr2[0])):
            large=r
        if (large != i):
            self.swap(i,large)
            self.siftdown(large)

    def heapsort(self):
        for i in range(self.pointer//2-1,0,-1):
            self.siftdown(i)
        w=self.pointer- 1
        for i in range(w, 0, -1):
            self.swap(0,i)
            self.pointer-=1
            self.siftdown(0)
        self.pointer=w+1
    def isempty(self):
        if(self.pointer==0):
            return 1
        else:
            return 0

    def siftdown2(self,i):
        min = i
        l = 2 * i + 1
        r = 2 * i + 2
        if(l<self.pointer):
           arrleft = str(self.heaparray[l]).split('$')
        else:
            arrleft=['',-1]
        arrmin = str(self.heaparray[min]).split('$')
        if (r < self.pointer):
            arrright = str(self.heaparray[r]).split('$')
        else:
            arrright=['',-1]
        if (l < self.pointer and int(arrleft[1]) < int(arrmin[1])):
            min=l
            arrmin=arrleft
        if (r < self.pointer and int(arrright [1]) < int(arrmin[1])):
            min=r
        if (min != i):
            self.swap(i,min)
            self.siftdown2(min)

    def heapsort2(self):
        for i in range(self.pointer // 2 - 1, -1, -1):
            self.siftdown2(i)
        w = self.pointer - 1
        for i in range(w, 0, -1):
            self.swap(0, i)
            self.pointer -= 1
            self.siftdown2(0)
        self.pointer = w + 1
        for i in range(self.pointer // 2):
            self.swap(i, (self.pointer - 1) - i)

    def pop2(self):
        x = self.heaparray[0]
        self.pointer = self.pointer - 1
        self.heaparray[0] = self.heaparray[self.pointer]
        self.siftdown2(0)
        self.heapsort2()
        return x

    def siftup2(self, i):
        parent = (i - 1) // 2
        arrparent = str(self.heaparray[parent]).split('$')
        arrchild = str(self.heaparray[i]).split('$')
        while (parent >= 0 and int(arrchild[1]) < int(arrparent[1])):
            self.swap(i, parent)
            i = parent
            parent = (i - 1) // 2
            arrparent = str(self.heaparray[parent]).split('$')
            arrchild = str(self.heaparray[i]).split('$')

    def insertheap2(self, x):
        self.heaparray[self.pointer] = x
        self.siftup2(self.pointer)
        self.pointer += 1