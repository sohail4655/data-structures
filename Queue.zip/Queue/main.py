class Queue:
    head=0
    tail=0
    capcity=0
    size=0
    def __init__(self,n):
        self.capcity=n
        self.array=[-1]*n
    def isempty(self):
        return self.size==0
    def isfull(self):
        return self.size == self.capcity
    def enqueue(self,value):
        if ( self.isfull() ):
            return
        self.array[self.tail]=value
        self.tail=(self.tail+1)%self.capcity
        self.size+=1
    def dequeue(self):
        if (self.isempty()):
            return
        x=self.array[self.head]
        self.head=(self.head+1) % self.capcity
        self.size=self.size-1
        return x
    def peek(self):
        return self.array[self.head]
    def display(self):
        if (self.isempty()):
            print("Queue is empty , can't display")
            return
        print("The Queue :", end=' ')
        k=self.head % self.capcity
        for i in range(self.size):
            value=self.dequeue()
            print(value, end='  ')
            self.enqueue(value)
        print("")
queue=Queue(5)
queue.enqueue(14)
queue.enqueue(17)
queue.enqueue(12)
queue.enqueue(19)
queue.display()