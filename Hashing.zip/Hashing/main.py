class Hash:
    capcity=13
    arr=[-1]*capcity
    size=0

class Linearprobing:
    hash = Hash()
    capcity = 0
    size = 0
    def __init__(self,hash:Hash):
        self.hash=hash
        self.capcity=hash.capcity
        self.size=hash.size
    def insert_LinearProbing(self,value):
        if(self.size==self.capcity):
            print("the hash is full , you need to rehash")
            return
        self.size=self.size+1
        index=value % self.capcity
        if(self.hash.arr[index]==-1 or self.hash.arr[index]==-2):
            self.hash.arr[index]=value
        else:
            for i in range(self.capcity-1):
                if (self.hash.arr[(index+i)%self.capcity] == -1 or self.hash.arr[(index+i)%self.capcity] == -2):
                    self.hash.arr[(index+i)%self.capcity] = value
                    break
    def search(self,value):
        index=value % self.capcity
        if(self.hash.arr[index]==value):
            print("found")
            return 1,index
        elif(self.hash.arr[index]== -1 or self.hash.arr[index]== -2):
            print("not found")
            return 0,0
        else:
            for i in range(1,self.capcity-1):
                if (self.hash.arr[(index+i)%self.capcity] == -1 and self.hash.arr[(index+i)%self.capcity] == -2):
                    print("not found")
                    return 0, 0
                elif(self.hash.arr[(index+i)%self.capcity] == value):
                        print("found")
                        return 1,(index+i)%self.capcity
                else:
                    print("not found")
                    return 0, 0
        print("not found")
        return 0, 0


    def delete(self,value):
        flag,index=self.search(value)
        if(flag==0):
            return
        else:
            self.size=self.size-1
            self.hash.arr[index]=-2


    def display(self):
        for i in range(self.capcity):
            print(i,end=':  ')
            print(self.hash.arr[i])
class Quadraticprobing:
    hash = Hash()
    capcity = 0
    size = 0
    def __init__(self,hash:Hash):
        self.hash=hash
        self.capcity=hash.capcity
        self.size=hash.size
    def insert_QuadraticProbing(self,value):
        if(self.size==self.capcity):
            print("the hash is full , you need to rehash")
            return
        self.size=self.size+1
        index=value % self.capcity
        if(self.hash.arr[index]==-1 or self.hash.arr[index]==-2):
            self.hash.arr[index]=value
        else:
            for i in range(1,self.capcity-1):
                if (self.hash.arr[(index+i*i)%self.capcity] == -1 or self.hash.arr[(index+i*i)%self.capcity] == -2):
                    self.hash.arr[(index+i*i)%self.capcity] = value
                    break
    def search(self,value):
        index=value % self.capcity
        if(self.hash.arr[index]==value):
            print("found")
            return 1,index
        elif(self.hash.arr[index]== -1 or self.hash.arr[index]== -2):
            print("not found")
            return 0,0
        else:
            for i in range(1,self.capcity-1):
                if (self.hash.arr[(index+i*i)%self.capcity] == -1 and self.hash.arr[(index+i*i)%self.capcity] == -2):
                    print("not found")
                    return 0, 0
                elif(self.hash.arr[(index+i*i)%self.capcity] == value):
                        print("found")
                        return 1,(index+i*i)%self.capcity
                else:
                    print("not found")
                    return 0, 0
        print("not found")
        return 0,0


    def delete(self,value):
        flag,index=self.search(value)
        if(flag==0):
            return
        else:
            self.size=self.size-1
            self.hash.arr[index]=-2


    def display(self):
        for i in range(self.capcity):
            print(i,end=':  ')
            print(self.hash.arr[i])
class DoubleHashing:
    hash = Hash()
    capcity = 0
    size = 0
    equation=''

    def __init__(self, hash: Hash,equation):
        self.hash = hash
        self.capcity = hash.capcity
        self.size = hash.size
        self.equation=equation
    def insert_doublehashing(self, value):
        if (self.size == self.capcity):
            print("the hash is full , you need to rehash")
            return
        self.size = self.size + 1
        index = value % self.capcity
        k=1
        if (self.hash.arr[index] == -1 or self.hash.arr[index] == -2):
            self.hash.arr[index] = value
        else:
            index2=eval(self.equation)
            print(index,end=' ')
            print(index2)
            for i in range(1, self.capcity - 1):
                if (self.hash.arr[(index + index2*k) % self.capcity] == -1 or self.hash.arr[
                    (index + index2*k) % self.capcity] == -2):
                    self.hash.arr[(index + index2*k) % self.capcity] = value
                    break
                k += 1

    def search(self, value):
        index = value % self.capcity
        index2=eval(self.equation)
        k=1
        if (self.hash.arr[index] == value):
            print("found")
            return 1, index
        elif (self.hash.arr[index] == -1 or self.hash.arr[index] == -2):
            print("not found")
            return 0, 0
        else:
            for i in range(1, self.capcity - 1):
                if (self.hash.arr[(index + index2*k) % self.capcity] == -1 and self.hash.arr[
                    (index + index2*k) % self.capcity] == -2):
                    print("not found")
                    return 0, 0
                elif (self.hash.arr[(index + index2*k) % self.capcity] == value):
                    print("found")
                    return 1, (index + index2*k) % self.capcity
                k+=1
        print("not found")
        return 0, 0

    def delete(self, value):
        flag, index = self.search(value)
        if (flag == 0):
            return
        else:
            self.size = self.size - 1
            self.hash.arr[index] = -2

    def display(self):
        for i in range(self.capcity):
            print(i, end=':  ')
            print(self.hash.arr[i])

hash1=Hash()
hash=DoubleHashing(hash1,"7-value%7")
hash.insert_doublehashing(18)
hash.insert_doublehashing(41)
hash.insert_doublehashing(22)
hash.insert_doublehashing(44)
hash.insert_doublehashing(59)
hash.insert_doublehashing(32)
hash.insert_doublehashing(31)
hash.insert_doublehashing(73)
hash.search(5)
hash.search(7)
hash.search(96)
hash.search(32)
hash.search(105)
hash.delete(31)
hash.display()